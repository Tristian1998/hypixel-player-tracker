/*
 * Skytils - Hypixel Skyblock Quality of Life Mod
 * Copyright (C) 2022 Skytils
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package skytils.skytilsmod.gui.profile.components

import gg.essential.elementa.UIComponent
import gg.essential.elementa.components.UIRoundedRectangle
import gg.essential.elementa.components.UIText
import gg.essential.elementa.components.Window
import gg.essential.elementa.constraints.CenterConstraint
import gg.essential.elementa.dsl.*
import gg.essential.elementa.state.State
import gg.essential.universal.ChatColor
import gg.essential.vigilance.gui.VigilancePalette
import skytils.hylin.skyblock.item.Inventory

class InventoryComponent(val inv: State<Inventory?>) : UIComponent() {
    init {
        inv.onSetValue(::parseInv)
        UIRoundedRectangle(5f).constrain {
            width = 100.percent
            height = 100.percent
            color = VigilancePalette.getBackground().constraint
        } childOf this
        UIText("Loading...").constrain {
            x = CenterConstraint()
            y = CenterConstraint()
        } childOf this
    }

    fun parseInv(inventory: Inventory?) = Window.enqueueRenderOperation {
        clearChildren()
        inventory?.run {
            for ((i, item) in items.withIndex()) {
                addChild(SlotComponent(item?.asMinecraft).constrain {
                    x = ((i % 9) * (16 + 2)).pixels
                    y = ((i / 9) * (16 + 2)).pixels
                })
            }
        } ?: kotlin.run {
            UIRoundedRectangle(5f).constrain {
                width = 100.percent
                height = 100.percent
                color = VigilancePalette.getBackground().constraint
            } childOf this
            UIText("Inventory api not enabled!").constrain {
                x = CenterConstraint()
                y = CenterConstraint()
            } childOf this
        }
    }
}